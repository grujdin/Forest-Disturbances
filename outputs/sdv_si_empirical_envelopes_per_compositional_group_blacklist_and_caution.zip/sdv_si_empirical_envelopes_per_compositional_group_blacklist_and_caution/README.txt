Algorithm #1 Phase 5 empirical optical envelopes and optional Sentinel-1 descriptor envelopes from shared caches.

Cache root: D:\Forest_Disturbance\outputs\sdv_phase3_preprocessing_cache
Cache manifest zip count: 60
Scene filter mode: blacklist_and_caution
Scenes used for envelope rows: 41
Unique dates used for envelopes: 40
Spectral indices: NDVI, NDMI, NBR, NDRE
Sentinel-1 descriptor envelopes enabled: True
Sentinel-1 cache root: D:\Forest_Disturbance\outputs\sdv_phase5_sentinel1_descriptor_cache
Sentinel-1 descriptors for envelopes: auto
DOY bin width: 30
Envelope quantiles: 0.1, 0.9
Plots enabled: True
Plot date source: unique_date
Plot points colored by year: True
Plot points connected within year: False
Plot curve min/max: True
Plot operational q10/q90 bounds: False
Plot pixel min/max bounds: False
Plot low-confidence DOY-bin markers: True
Envelope confidence thresholds: high >= 5 unique dates; medium >= 3; minimum support pixels for medium = 1000
Operational bounds later used by Algorithm #2: median_of_date_q10 and median_of_date_q90.
Phase 4 confidence fields are diagnostic; they do not alter the envelope values.
