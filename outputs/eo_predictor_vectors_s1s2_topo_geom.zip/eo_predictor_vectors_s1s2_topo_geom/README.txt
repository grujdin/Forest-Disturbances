EO predictor vector construction for Algorithm #4 candidate loss objects.

The output vector follows the article feature-block structure:
  x = [x_EO, x_delta, x_shape, x_topo, m]

Main output files:
  eo_predictor_vector_all_intervals.csv
  eo_predictor_vector_all_intervals.gpkg
  eo_predictor_feature_dictionary.csv
  topography_cache/*.tif

DEM source: D:\Forest_Disturbance\imagery_zip\SdV_DEM_Copernicus_30.zip
Algorithm #4 root: D:\Forest_Disturbance\outputs\rdf_loss_objects_graphdb_annual_s1s2_blacklist_and_caution_eligible_phase5
S2 cache root: D:\Forest_Disturbance\outputs\sdv_phase3_preprocessing_cache
S1 cache root: D:\Forest_Disturbance\outputs\sdv_phase5_sentinel1_descriptor_cache
Projected CRS for geometry/topography: EPSG:32634
Topographic variables include elevation, slope, northness, eastness, D30, D120, TPI3, and roughness3.
Geometric variables include area, perimeter, compactness, elongation, solidity, convexity, edge complexity, orientation, and part/hole counts.
